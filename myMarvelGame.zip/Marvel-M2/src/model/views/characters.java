package model.views;

import java.util.ArrayList;

import model.world.Champion;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class characters implements MouseListener {

	 ArrayList<Champion> champions;
	 String f;
	 String s;
	 ArrayList<Champion> fTeam;
	 ArrayList<Champion> sTeam;
	 Champion fLeader;
	 Champion sLeader;
	
	 JFrame window;
	 JLabel back;
	 JPanel menu;
	 ArrayList<JButton> choose;
	 ArrayList<JButton> firstTeam;
	 ArrayList<JButton> secondTeam;
	 boolean [] used;
	 ArrayList<Integer> index1;
	 ArrayList<Integer> index2;
	 JTextArea display;
	 JButton firstLeader;
	 JButton secondLeader;
	 JButton next;
	
	public characters( ArrayList<Champion> champions , String FirstName, String SecondName)
	{
		
		this.champions  =champions;
		f = FirstName;
		s = SecondName;
		
		
		fTeam = new ArrayList<Champion>();
		sTeam = new ArrayList<Champion>();
		used = new boolean[15];
		index1 = new ArrayList<Integer>();
		index2 = new ArrayList<Integer>();
		
		
		window = new JFrame("Marvel: Ultimate War");
		window.setSize(1300,1000);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setLocationRelativeTo(null);
		window.setLayout(null);
		window.setIconImage(new ImageIcon("logo.jpg").getImage());
		
		back = new JLabel();
		back.setBounds(0,0,1300,1000);
		back.setIcon( new ImageIcon("backGround.jpg"));
		
		menu = new JPanel();
		menu.setBounds(320,20,650,700);
		menu.setBackground(Color.black);
		menu.setLayout(new GridLayout(5,5,5,3));
		
		choose = new ArrayList<JButton>();
		
		for( int i = 0 ; i < 15 ; ++i)
		{
			JButton k = new JButton();
			k.setText(champions.get(i).getName());
			k.setIcon(new ImageIcon(champions.get(i).getName() + ".jpg"));
			k.setBorder( BorderFactory.createLineBorder(Color.white,4,true));
			k.addMouseListener(this);
			menu.add(k);
			choose.add(k);
			
		}
		
		this.firstTeam = new ArrayList<JButton>();
		this.secondTeam = new ArrayList<JButton>();
		
		for( int i= 0 ; i<3 ; ++i)
		{
			JButton k = new JButton();
			JButton m = new JButton();
			k.setText( (i+1) +"");
			m.setText( (i+1) +"");
			k.setBackground(new Color(0,0,205));
			m.setBackground(new Color(128,0,0));
			k.setBorder(BorderFactory.createLineBorder(Color.white,4,true));
			m.setBorder(BorderFactory.createLineBorder(Color.white,4,true));
			k.setForeground(Color.white);
			m.setForeground(Color.white);
			
			k.addMouseListener(this);
			m.addMouseListener(this);
			
			firstTeam.add(k);
			secondTeam.add(m);
		}
		
		firstLeader = new JButton();
		secondLeader = new JButton();
		
		
		firstTeam.get(0).setBounds(10,70,220,140); back.add(firstTeam.get(0));
		firstTeam.get(1).setBounds(10,270,220,140); back.add(firstTeam.get(1));
		firstTeam.get(2).setBounds(10,470,220,140); back.add(firstTeam.get(2));
		firstLeader.setBounds(10,670,220,140); 
		firstLeader.setBackground(new Color(0,0,205));
		firstLeader.setText("First Leader");
		firstLeader.setForeground(Color.white);
		firstLeader.setBorder(BorderFactory.createLineBorder(Color.white,4,true));
		back.add(firstLeader);
		
		secondTeam.get(0).setBounds(1045,70,220,140); back.add(secondTeam.get(0));
		secondTeam.get(1).setBounds(1045,270,220,140); back.add(secondTeam.get(1));
		secondTeam.get(2).setBounds(1045,470,220,140); back.add(secondTeam.get(2));
		secondLeader.setBounds(1045,670,220,140); 
		secondLeader.setText("Second Leader");
		secondLeader.setForeground(Color.white);
		secondLeader.setBackground(new Color(128,0,0));
		secondLeader.setBorder(BorderFactory.createLineBorder(Color.white,4,true));
		back.add(secondLeader);
		
		back.add(menu);
		
		display = new JTextArea();
		display.setBounds(500,740,300,250);
		display.setFont(new Font("",Font.BOLD,16));
		display.setBackground(Color.black);
		display.setForeground(Color.white);
		display.setBorder( BorderFactory.createLineBorder(Color.white,4,true));
		display.setVisible(false);
		back.add(display);
		
		next = new JButton("Next");
		next.setBounds(1050,850,200,100); 
		next.setBackground(new Color(128,0,0));
		next.setForeground(Color.white);
		next.setFont( new Font("" , Font.BOLD,16));
		next.setBorder(BorderFactory.createLineBorder(Color.white,4,true));
		next.setVisible(false);
		next.addMouseListener(this);
		back.add(next);
		
		window.add(back);
		window.setVisible(true);
	}

	
	public void mouseClicked(MouseEvent e) 
	{
		
		for( int i = 0 ; i<15 ; ++i)
		{

			if(e.getSource().equals(choose.get(i))&& !used[i])
			{
				
				if(fTeam.size() < 3 )
				{
					index1.add(i);
					firstTeam.get(fTeam.size()).setIcon( choose.get(i).getIcon());
					fTeam.add(champions.get(i));
					used[i] = true;
					choose.get(i).setEnabled(false);
				}
				else if(sTeam.size() < 3)
				{
					index2.add(i);
					secondTeam.get(sTeam.size()).setIcon( choose.get(i).getIcon());
					sTeam.add(champions.get(i));
					used[i] = true;
					choose.get(i).setEnabled(false);
				}
				
				}
				
			}
		
		if(fTeam.size() == 3 && sTeam.size() == 3 ) 
		{
			for(int j = 0 ; j < 3 ; ++j) {
				if( e.getSource().equals(firstTeam.get(j)))
				{
					fLeader = champions.get(index1.get(j));
					firstLeader.setIcon(firstTeam.get(j).getIcon());
					}
					
				if( e.getSource().equals(secondTeam.get(j)))
				{
					sLeader = champions.get(index2.get(j));
					secondLeader.setIcon(secondTeam.get(j).getIcon());
				}
				
			}
			
		}
		
		 if(fLeader == null || sLeader == null)
		 {
			 if(fTeam.size() == 3 && sTeam.size() == 3)
				JOptionPane.showMessageDialog(null, "Both Players Must Select a Leader by Clicking on one of The Selected Champions in their Team");
		 }
		else
		{
			next.setVisible(true);
		}
		 
		 if(e.getSource().equals(next))
		 {
			 window.dispose();
			new  rumble(fTeam,sTeam,fLeader,sLeader,f,s);
		 }
	}
	

	public void mousePressed(MouseEvent e) {
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		
		String s = "";
		for( int i = 0 ; i< 15 ; ++i)
		{
			if(e.getSource().equals(choose.get(i)))
			{
			
				s += "Name : " + champions.get(i).getName() +  "\n" + "MaxHp : " + champions.get(i).getMaxHP() + "\n" + "Attack Damage : "+ champions.get(i).getAttackDamage() + "\n" +
					"Attack Range : " + champions.get(i).getAttackRange() + "\n" + "Max Action Points : " + champions.get(i).getMaxActionPointsPerTurn() + "\n" + 
					"Speed : " + champions.get(i).getSpeed() + "\n " + "Mana : " + champions.get(i).getMana() + "\n" + "firstAbility : "+ champions.get(i).getAbilities().get(0).getName() + "\n" + 
					"secondAbility : "+ champions.get(i).getAbilities().get(1).getName() + "\n" +  "thirdAbility : "+ champions.get(i).getAbilities().get(2).getName() + "\n" ;
				display.setVisible(true);
				display.setText(s);
				break;
			}
		}
		
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		
		display.setVisible(false);
		display.setText("");
		
	}
	

	
}
