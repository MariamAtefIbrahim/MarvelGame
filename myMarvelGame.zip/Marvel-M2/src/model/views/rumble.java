package model.views;

import java.util.ArrayList;

import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Cover;
import model.world.Damageable;
import model.world.Direction;
import model.world.Hero;

import javax.swing.*;
import javax.swing.text.AttributeSet.ColorAttribute;

import engine.Game;
import engine.Player;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;

import java.awt.*;
import java.awt.event.*;

public class rumble implements MouseListener, KeyListener

{
	ArrayList<Champion> team1 ;
	ArrayList<Champion> team2 ;
	Champion Leader1 ;
	Champion Leader2 ;
	String firstName;
	String secondName;
	Game game;
	
	
	JFrame window;
	JLabel back1;
	JLabel back2;
	JPanel board;
	JButton [][] champions;
	JLabel main;
	boolean[] check;
	JLabel firstN;
	JLabel secondN;
	JLabel abilityL1;
	JLabel abilityL2;
	
	JLabel champion1;
	JTextArea info1;
	
	JLabel champion2;
	JTextArea info2;
	
	JLabel champion3;
	JTextArea info3;
	
	JLabel champion4;
	JTextArea info4;
	
	JLabel champion5;
	JTextArea info5;
	
	JLabel champion6;
	JTextArea info6;
	
	JLabel current;
	JTextArea infoCurrent;
	
	JTextArea infoAbility;
	
	
	ArrayList<JLabel> champs;
	ArrayList<JTextArea> info;
	ArrayList<Champion> tmp1;
	ArrayList<Champion> tmp2;
	
	
	JButton move;
	JButton attack;
	JButton firstAbility;
	JButton secondAbility;
	JButton thirdAbility;
	JButton leaderAbility;
	JButton endTurn;

	boolean [] actions = new boolean[3];

 	Ability ability;
	
	public rumble(ArrayList<Champion> team1 ,ArrayList<Champion> team2 ,Champion Leader1 , Champion Leader2 , String firstName , String secondName ) 
	{
		this.team1 = team1;
		this.team2 = team2;
		this.Leader1 = Leader1;
		this.Leader2 = Leader2;
		this.firstName = firstName;
		this.secondName = secondName;
		
		Player first = new Player(firstName);
		Player second = new Player(secondName);
		
		first.getTeam().addAll(team1);
		second.getTeam().addAll(team2);
		first.setLeader(Leader1);
		second.setLeader(Leader2);
		game = new Game(first, second);
		
		
		check = new boolean[4];
		
		window = new JFrame("Marvel: Ultimate War");
		window.setSize(1300,1000);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setLocationRelativeTo(null);	
		window.setLayout(null);
		window.setIconImage(new ImageIcon("logo.jpg").getImage());
		
		back1 = new JLabel();
		back1.setBounds(0,0,500,500);
		back1.setOpaque(true);
		back1.setBackground(new Color(0,0,205));
		back1.setBorder(BorderFactory.createLineBorder(Color.black,4,true));
		
		firstN = new JLabel(firstName);
		firstN.setForeground(Color.white);
		firstN.setBounds(5,0,250,50);
		firstN.setFont( new Font ("",Font.BOLD,20));
		
		abilityL1 = new JLabel("Leader Ability : Not Used");
		abilityL1.setForeground(Color.white);
		abilityL1.setBounds(250,0,250,50);
		abilityL1.setFont( new Font ("",Font.BOLD,20));
		back1.add(abilityL1);
		back1.add(firstN);
	
		back2 = new JLabel();
		back2.setBounds(0,500,500,500);
		back2.setOpaque(true);
		back2.setBackground(new Color(128,0,0));
		back2.setBorder(BorderFactory.createLineBorder(Color.black,4,true));

		secondN = new JLabel(secondName);
		secondN.setForeground(Color.white);
		secondN.setBounds(5,0,250,50);
		secondN.setFont( new Font ("",Font.BOLD,20));
		abilityL2 = new JLabel("Leader Ability : Not Used");
		abilityL2.setForeground(Color.white);
		abilityL2.setBounds(250,0,250,50);
		abilityL2.setFont( new Font ("",Font.BOLD,20));
		back2.add(abilityL2);
		back2.add(secondN);
		
		
		champions =  new JButton[5][5];
		for(int i = 0 ; i< 5 ; ++i)
			for(int j = 0 ; j< 5 ; ++j)
			{
				JButton x = new JButton();
				x.setBackground(Color.black);
				x.setBorder(BorderFactory.createLineBorder(Color.white,2,true));
				x.addMouseListener(this);
				champions[i][j] = x;
			}
		board =  new JPanel();
		board.setBackground(Color.black);
		board.setLayout(new GridLayout(5,5,5,5));
		board.addKeyListener(this);
		board.setBounds(500,0,785,700);
		
		for( int i = 4 ; i>=0 ; --i)
			for( int j = 0 ; j< 5 ; ++j)
				board.add(champions[i][j]);
		
		
		int yT1 = 1;
		int yT2 = 1;
		
		
		
		Object [][] check = game.getBoard() ;
		for(int i= 0 ; i< 5 ; i++)
			for(int j = 0 ; j < 5 ; ++j)
			{
				if(check[i][j] instanceof Cover)
				{
					champions[i][j].setIcon(new ImageIcon("cover.jpg"));
					champions[i][j].setHorizontalTextPosition(JLabel.CENTER);
					champions[i][j].setForeground(Color.white);
					champions[i][j].setText("" + ((Cover)check[i][j]).getCurrentHP());
					
					}
				if (check[i][j] instanceof Champion)
					champions[i][j].setIcon(new ImageIcon( ((Champion)check[i][j]).getName() +".jpg" ));
			}
		String s ="";
		String  t ="";
		
		champion1  = new JLabel(new ImageIcon(team1.get(0).getName() + ".jpg"));
		champion1.setBounds(10,75,200,120);
		champion1.addMouseListener(this);
		
		if(team1.get(0) == Leader1)
		{
			champion1.setText("Leader");
			champion1.setHorizontalTextPosition(JLabel.CENTER);
			champion1.setFont( new Font("",Font.BOLD,30));
			champion1.setForeground(new Color(218,165,32));
		}
		back1.add(champion1);
		info1 = new JTextArea();
		info1.setBackground(new Color(0,0,205));
		info1.setBounds(220,75,270,120);
		info1.setForeground(Color.white);
		info1.setEditable(false);
		
		 if(team1.get(0) instanceof Hero)
			 t ="Hero";
		 else if(team1.get(0) instanceof AntiHero)
			 t ="AntiHero";
		 else
			 t ="Villain";
		
		s += "Name : " + team1.get(0).getName() + " " + t +  "\n" + "Hp : " +  team1.get(0).getMaxHP() + "\n" + "Attack Damage : "+  team1.get(0).getAttackDamage() + "\n" +
				"Attack Range : " +  team1.get(0).getAttackRange() + "\n" + "Current Action Points : " +  team1.get(0).getCurrentActionPoints() + "\n" + 
				"Speed : " +  team1.get(0).getSpeed() + "\n" + "Mana : " + team1.get(0).getMana();
		
		info1.setText(s);
		back1.add(info1);
		
		s="";
		
		champion2  = new JLabel(new ImageIcon(team1.get(1).getName() + ".jpg"));
		champion2.setBounds(10,205,200,120);
		champion2.addMouseListener(this);
		if(team1.get(1) == Leader1)
		{
			champion2.setText("Leader");
			champion2.setHorizontalTextPosition(JLabel.CENTER);
			champion2.setFont( new Font("",Font.BOLD,30));
			champion2.setForeground(new Color(218,165,32));
		}
		
		back1.add(champion2);
		info2 = new JTextArea();
		info2.setBackground(new Color(0,0,205));
		info2.setBounds(220,205,270,120);
		info2.setForeground(Color.white);
		info2.setEditable(false);
		
		 if(team1.get(1) instanceof Hero)
			 t ="Hero";
		 else if(team1.get(1) instanceof AntiHero)
			 t ="AntiHero";
		 else
			 t ="Villain";
		
		s += "Name : " + team1.get(1).getName()+ " " + t +  "\n" + "Hp : " +  team1.get(1).getMaxHP() + "\n" + "Attack Damage : "+  team1.get(1).getAttackDamage() + "\n" +
				"Attack Range : " +  team1.get(1).getAttackRange() + "\n" + "Current Action Points : " +  team1.get(1).getCurrentActionPoints() + "\n" + 
				"Speed : " +  team1.get(1).getSpeed() + "\n" + "Mana : " + team1.get(1).getMana();
		
		info2.setText(s);
		back1.add(info2);
		
		s="";
		champion3 = new JLabel(new ImageIcon(team1.get(2).getName() + ".jpg"));
		champion3.setBounds(10,335,200,120);
		champion3.addMouseListener(this);
		if(team1.get(2) == Leader1)
		{
			champion3.setText("Leader");
			champion3.setHorizontalTextPosition(JLabel.CENTER);
			champion3.setFont( new Font("",Font.BOLD,30));
			champion3.setForeground(new Color(218,165,32));
		}
		
		back1.add(champion3);
		info3 = new JTextArea();
		info3.setBackground(new Color(0,0,205));
		info3.setBounds(220,335,270,120);
		info3.setForeground(Color.white);
		info3.setEditable(false);
		
		 if(team1.get(2) instanceof Hero)
			 t ="Hero";
		 else if(team1.get(2) instanceof AntiHero)
			 t ="AntiHero";
		 else
			 t ="Villain";
		 
		s += "Name : " + team1.get(2).getName() + " " + t+  "\n" + "Hp : " +  team1.get(2).getMaxHP() + "\n" + "Attack Damage : "+  team1.get(2).getAttackDamage() + "\n" +
				"Attack Range : " +  team1.get(2).getAttackRange() + "\n" + "Current Action Points : " +  team1.get(2).getCurrentActionPoints() + "\n" + 
				"Speed : " +  team1.get(2).getSpeed() + "\n" + "Mana : " + team1.get(2).getMana();
		
		info3.setText(s);
		back1.add(info3);
		
		
		s="";
		
		champion4 = new JLabel(new ImageIcon(team2.get(0).getName() + ".jpg"));
		champion4.setBounds(10,75,200,120);
		champion4.addMouseListener(this);
		if(team2.get(0) == Leader2)
		{
			champion4.setText("Leader");
			champion4.setHorizontalTextPosition(JLabel.CENTER);
			champion4.setFont( new Font("",Font.BOLD,30));
			champion4.setForeground(new Color(218,165,32));
		}
		
		back2.add(champion4);
		info4 = new JTextArea();
		info4.setBackground(new Color(128,0,0));
		info4.setBounds(220,75,270,120);
		info4.setForeground(Color.white);
		info4.setEditable(false);
		
		 if(team2.get(0) instanceof Hero)
			 t ="Hero";
		 else if(team2.get(0) instanceof AntiHero)
			 t ="AntiHero";
		 else
			 t ="Villain";
		
		s += "Name : " + team2.get(0).getName()+ " " + t +  "\n" + "Hp : " +  team2.get(0).getMaxHP() + "\n" + "Attack Damage : "+  team2.get(0).getAttackDamage() + "\n" +
				"Attack Range : " +  team2.get(0).getAttackRange() + "\n" + "Current Action Points : " +  team2.get(0).getCurrentActionPoints() + "\n" + 
				"Speed : " +  team2.get(0).getSpeed() + "\n" + "Mana : " + team2.get(0).getMana();
		
		info4.setText(s);
		back2.add(info4);
		
		s = "";
		champion5 = new JLabel(new ImageIcon(team2.get(1).getName() + ".jpg"));
		champion5.setBounds(10,205,200,120);
		champion5.addMouseListener(this);
		
		if(team2.get(1) == Leader2)
		{
			champion5.setText("Leader");
			champion5.setHorizontalTextPosition(JLabel.CENTER);
			champion5.setFont( new Font("",Font.BOLD,30));
			champion5.setForeground(new Color(218,165,32));
		}
		back2.add(champion5);
		info5 = new JTextArea();
		info5.setBackground(new Color(128,0,0));
		info5.setBounds(220,205,270,120);
		info5.setForeground(Color.white);
		info5.setEditable(false);
		
		 if(team2.get(1) instanceof Hero)
			 t ="Hero";
		 else if(team2.get(1) instanceof AntiHero)
			 t ="AntiHero";
		 else
			 t ="Villain";
		
		s += "Name : " + team2.get(1).getName()+ " " + t +  "\n" + "Hp : " +  team2.get(1).getMaxHP() + "\n" + "Attack Damage : "+  team2.get(1).getAttackDamage() + "\n" +
				"Attack Range : " +  team2.get(1).getAttackRange() + "\n" + "Current Action Points : " +  team2.get(1).getCurrentActionPoints() + "\n" + 
				"Speed : " +  team2.get(1).getSpeed() + "\n" + "Mana : " + team2.get(1).getMana();
		
		info5.setText(s);
		back2.add(info5);
		s ="";
		champion6 = new JLabel(new ImageIcon(team2.get(2).getName() + ".jpg"));
		champion6.setBounds(10,335,200,120);
		champion6.addMouseListener(this);
		
		if(team2.get(2) == Leader2)
		{
			champion6.setText("Leader");
			champion6.setHorizontalTextPosition(JLabel.CENTER);
			champion6.setFont( new Font("",Font.BOLD,30));
			champion6.setForeground(new Color(218,165,32));
		}
		
		back2.add(champion6);
		info6 = new JTextArea();
		info6.setBackground(new Color(128,0,0));
		info6.setBounds(220,335,270,120);
		info6.setForeground(Color.white);
		info6.setEditable(false);
		
		 if(team2.get(2) instanceof Hero)
			 t ="Hero";
		 else if(team2.get(2) instanceof AntiHero)
			 t ="AntiHero";
		 else
			 t ="Villain";
		s += "Name : " + team2.get(2).getName() + " " + t+  "\n" + "Hp : " +  team2.get(2).getMaxHP() + "\n" + "Attack Damage : "+  team2.get(2).getAttackDamage() + "\n" +
				"Attack Range : " +  team2.get(2).getAttackRange() + "\n" + "Current Action Points : " +  team2.get(2).getCurrentActionPoints() + "\n" + 
				"Speed : " +  team2.get(2).getSpeed() + "\n" + "Mana : " + team2.get(2).getMana();
		
		info6.setText(s);
		back2.add(info6);
		s="";
		
		
		
		main = new JLabel(new ImageIcon("current.jpg"));
		main.setBounds(500,700,800,400);
		
		
		 current = new JLabel(new ImageIcon(game.getCurrentChampion().getName() +".jpg")) ;
		 current.setBounds(320,20,170,120);
		 current.setBorder(BorderFactory.createLineBorder(new Color(218,165,32),2 ));
		 current.addMouseListener(this);
		 main.add(current);
		 
		 infoCurrent  = new JTextArea();
		 infoCurrent.setBackground(new Color(218,165,32));
		 infoCurrent.setBounds(10,19,200,120);
		 infoCurrent.setForeground(Color.white);
		 infoCurrent.setBorder(BorderFactory.createLineBorder(Color.white,2 ));
		 
		 infoAbility = new JTextArea();
		 infoAbility.setBackground(new Color(218,165,32));
		 infoAbility.setBounds(570,10,180,150);
		 infoAbility.setForeground(Color.black);
		 infoAbility.setEditable(false);
		 infoAbility.setBorder(BorderFactory.createLineBorder(Color.white,2 ));
		 infoAbility.setForeground(Color.white);
		 main.add(infoAbility);
	
		 if(game.getCurrentChampion() instanceof Hero)
			 t ="Hero";
		 else if( game.getCurrentChampion() instanceof AntiHero)
			 t ="AntiHero";
		 else
			 t ="Villain";
		 
		 s += "Name : " + game.getCurrentChampion().getName() +" " + t +  "\n" + "Hp : " +  game.getCurrentChampion().getMaxHP() + "\n" + "Attack Damage : "+  game.getCurrentChampion().getAttackDamage() + "\n" +
					"Attack Range : " +  game.getCurrentChampion().getAttackRange() + "\n" + "Current Action Points : " +  game.getCurrentChampion().getCurrentActionPoints() + "\n" + 
					"Speed : " +  game.getCurrentChampion().getSpeed() + "\n" + "Mana : " + game.getCurrentChampion().getMana(); 
		 infoCurrent.setText(s);
		 main.add(infoCurrent);
		 
		 info = new ArrayList<JTextArea>();
		 champs = new ArrayList<JLabel>();
		 
		 info.add(info1); info.add(info2); info.add(info3); info.add(info4); info.add(info5); info.add(info6); 
		 
		 
		

		 
		 tmp1 = team1;
		 tmp2 = team2;
		 
		 move = new JButton("Move");
		 move.setBounds(10,180,100,50);
		 move.addMouseListener(this);
		 move.addKeyListener(this);
		 move.setBackground(new Color(218,165,32));
		 move.setBorder(BorderFactory.createLineBorder(Color.white,2));
		 move.setForeground(Color.white);
		 main.add(move);
		 
		 
		 attack = new JButton("Attack");
		 attack.setBounds(120,180,100,50);
		 attack.addMouseListener(this);
		 attack.addKeyListener(this);
		 attack.setBackground(new Color(218,165,32));
		 attack.setBorder(BorderFactory.createLineBorder(Color.white,2));
		 attack.setForeground(Color.white);
		 main.add(attack);
		 
		 firstAbility = new JButton("firstAbility");
		 firstAbility.setBounds(230,180,100,50);
		 firstAbility.addMouseListener(this);
		 firstAbility.addKeyListener(this);
		 firstAbility.setBackground(new Color(218,165,32));
		 firstAbility.setBorder(BorderFactory.createLineBorder(Color.white,2 ));
		 firstAbility.setForeground(Color.white);
		 main.add(firstAbility);
		 
		 secondAbility = new JButton("secondAbility");
		 secondAbility.setBounds(340,180,110,50);
		 secondAbility.addMouseListener(this);
		 secondAbility.addKeyListener(this);
		 secondAbility.setBackground(new Color(218,165,32));
		 secondAbility.setBorder(BorderFactory.createLineBorder(Color.white,2 ));
		 secondAbility.setForeground(Color.white);
		 main.add (secondAbility);
		 
		 thirdAbility = new JButton("thirdAbility");
		 thirdAbility.setBounds(460,180,100,50);
		 thirdAbility.addMouseListener(this);
		 thirdAbility.addKeyListener(this); 
		 thirdAbility.setBackground(new Color(218,165,32));
		 thirdAbility.setBorder(BorderFactory.createLineBorder(Color.white,2 ));
		 thirdAbility.setForeground(Color.white);
		 main.add( thirdAbility);
		
		
		leaderAbility = new JButton("LeaderAbility");
		leaderAbility.addMouseListener(this);
		leaderAbility.addKeyListener(this);
		leaderAbility.setBounds(570,180,115,50);
		 leaderAbility.setBackground(new Color(218,165,32));
		 leaderAbility.setBorder(BorderFactory.createLineBorder(Color.white,2 ));
		 leaderAbility.setForeground(Color.white);
		main.add(leaderAbility);
		
		endTurn = new JButton("endTurn");
		endTurn.addMouseListener(this);
		endTurn.addKeyListener(this);
		endTurn.setBounds(690,180,100,50);
		 endTurn.setBackground(new Color(218,165,32));
		 endTurn.setBorder(BorderFactory.createLineBorder(Color.white,2 ));
		endTurn.setForeground(Color.white);
		main.add(endTurn);
		
		
		
		
			
		window.add(back1);
		window.add(back2);
		window.add(board);
		window.add(main);
		
		window.setVisible(true);
	
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(actions[0])
		{
			Point old = game.getCurrentChampion().getLocation();
			if( e.getKeyCode() == 37)
			{
				try {
					game.move(Direction.LEFT);
					champions[old.x][old.y].setIcon(null);
					Point New = game.getCurrentChampion().getLocation();
					champions[New.x][New.y].setIcon(new ImageIcon(game.getCurrentChampion().getName() +".jpg"));
				} catch (NotEnoughResourcesException | UnallowedMovementException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
				
			}
			if( e.getKeyCode() == 38)
			{
				try {
					game.move(Direction.UP);
					champions[old.x][old.y].setIcon(null);
					Point New = game.getCurrentChampion().getLocation();
					champions[New.x][New.y].setIcon(new ImageIcon(game.getCurrentChampion().getName() +".jpg"));
				} catch (NotEnoughResourcesException | UnallowedMovementException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
				
			}
			if( e.getKeyCode() == 39)
			{
				try {
					game.move(Direction.RIGHT);
					champions[old.x][old.y].setIcon(null);
					Point New = game.getCurrentChampion().getLocation();
					champions[New.x][New.y].setIcon(new ImageIcon(game.getCurrentChampion().getName() +".jpg"));
				} catch (NotEnoughResourcesException | UnallowedMovementException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
				
			}
			if( e.getKeyCode() == 40)
			{
				try {
					game.move(Direction.DOWN);
					champions[old.x][old.y].setIcon(null);
					Point New = game.getCurrentChampion().getLocation();
					champions[New.x][New.y].setIcon(new ImageIcon(game.getCurrentChampion().getName() +".jpg"));
				} catch (NotEnoughResourcesException | UnallowedMovementException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
				
			}
			actions[0] = false;
		}
		else if (actions[1])
		{
			if(e.getKeyCode() == 37)
				{
					try {
						game.attack(Direction.LEFT);
					} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage());
					}
				}
			else if(e.getKeyCode() == 38)
				{
				try {
					game.attack(Direction.UP);
				} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
				}
			else if(e.getKeyCode() == 39)
				{
				try {
					game.attack(Direction.RIGHT);
				} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
				}
			else	if(e.getKeyCode() == 40)
				{
				try {
					game.attack(Direction.DOWN);
				} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
				}
			actions[1] =false;
		}
		else if (actions[2])
		{
			if(e.getKeyCode() == 37)
			{
				try {
					game.castAbility(ability, Direction.LEFT);
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
			else if(e.getKeyCode() == 38)
			{
				try {
					game.castAbility(ability, Direction.UP);
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
			else if( e.getKeyCode() == 39)
			{
				try {
					game.castAbility(ability, Direction.RIGHT);
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
			else if (e.getKeyCode() == 40)
			{
				try {
					game.castAbility(ability, Direction.DOWN);
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
			actions[2] =false;
		}
		
		
		String s ="";
		String t ="";

		for( int i = 0; i< 3 ; ++i)
		{
			Champion c = tmp1.get(i);
			 if(c instanceof Hero)
				 t ="Hero";
			 else if( c instanceof AntiHero)
				 t ="AntiHero";
			 else
				 t ="Villain";
			 s += "Name : " +c.getName() +" " + t +  "\n" + "Hp : " +  c.getCurrentHP() + "\n" + "Attack Damage : "+ c.getAttackDamage() + "\n" +
						"Attack Range : " +  c.getAttackRange() + "\n" + "Current Action Points : " +  c.getCurrentActionPoints() + "\n" + 
						"Speed : " + c.getSpeed() + "\n" + "Mana : " + c.getMana(); 
			info.get(i).setText(s);
			s= "";
		}
		
		int j = 0;
		for( int i = 3; i< 6 ; ++i)
		{
			Champion c = tmp2.get(j);
			 if(c instanceof Hero)
				 t ="Hero";
			 else if( c instanceof AntiHero)
				 t ="AntiHero";
			 else
				 t ="Villain";
			 s += "Name : " +c.getName() +" " + t +  "\n" + "Hp : " +  c.getCurrentHP() + "\n" + "Attack Damage : "+ c.getAttackDamage() + "\n" +
						"Attack Range : " +  c.getAttackRange() + "\n" + "Current Action Points : " +  c.getCurrentActionPoints() + "\n" + 
						"Speed : " + c.getSpeed() + "\n" + "Mana : " + c.getMana(); 
			info.get(i).setText(s);
			s= "";
			++j;
		}
		
		 if(game.getCurrentChampion() instanceof Hero)
			 t ="Hero";
		 else if( game.getCurrentChampion() instanceof AntiHero)
			 t ="AntiHero";
		 else
			 t ="Villain";
		 
		 s += "Name : " + game.getCurrentChampion().getName() +" " + t +  "\n" + "Hp : " +  game.getCurrentChampion().getCurrentHP() + "\n" + "Attack Damage : "+  game.getCurrentChampion().getAttackDamage() + "\n" +
					"Attack Range : " +  game.getCurrentChampion().getAttackRange() + "\n" + "Current Action Points : " +  game.getCurrentChampion().getCurrentActionPoints() + "\n" + 
					"Speed : " +  game.getCurrentChampion().getSpeed() + "\n" + "Mana : " + game.getCurrentChampion().getMana(); 
		 infoCurrent.setText(s);
		
		 
			
			Object [][] check = game.getBoard();
				 
			for( int i=0 ; i < 5; ++i)
			{
				for( int k = 0 ; k< 5 ; ++k)
				{
					if( check[i][k] == null)
					{
						champions[i][k].setIcon(null);
						champions[i][k].setText("");
					}
					
				}
			}
			
			for( int i=0 ; i < 5; ++i)
			
				for( int k = 0 ; k< 5 ; ++k)
			 if( check[i][k] instanceof Cover )
					champions[i][k].setText( ((Cover)check[i][k]).getCurrentHP()  + "");
		
	}

	@Override
	public void keyReleased(KeyEvent e) 
	{
		System.out.println(e.getKeyCode());
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	
		boolean single = false;
	
		if(e.getSource().equals(move))
		{
			actions[0] = true;
			actions[1] = false;
			actions[2] = false;
			
		}
		
		if(e.getSource().equals(attack))
		{
			actions[0] = false;
			actions[1] = true;
			actions[2] = false;
			
		}
		
		if(e.getSource().equals(firstAbility) )
		{
			ability = game.getCurrentChampion().getAbilities().get(0);
			if(ability.getCastArea() != AreaOfEffect.DIRECTIONAL && ability.getCastArea() != AreaOfEffect.SINGLETARGET)
				try {
					game.castAbility(ability);
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			else if ( ability.getCastArea() == AreaOfEffect.DIRECTIONAL)
			{
				actions[0] = false;
				actions[1] = false;
				actions[2] = true;
				
			}
			else if (ability.getCastArea() == AreaOfEffect.SINGLETARGET) {
				single = true;
				}
		}
		
				
		
		if(e.getSource().equals(secondAbility) )
		{
			ability = game.getCurrentChampion().getAbilities().get(1);
			if(ability.getCastArea() != AreaOfEffect.DIRECTIONAL && ability.getCastArea() != AreaOfEffect.SINGLETARGET)
				try {
					game.castAbility(ability);
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			else if ( ability.getCastArea() == AreaOfEffect.DIRECTIONAL)
			{
				actions[0] = false;
				actions[1] = false;
				actions[2] = true;
			
			}
			else if (ability.getCastArea() == AreaOfEffect.SINGLETARGET) 
			{
				single = true;
			}
		}
		
		
		if(e.getSource().equals(thirdAbility) )
		{
			ability = game.getCurrentChampion().getAbilities().get(2);
			if(ability.getCastArea() != AreaOfEffect.DIRECTIONAL && ability.getCastArea() != AreaOfEffect.SINGLETARGET)
				try {
					game.castAbility(ability);
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			else if ( ability.getCastArea() == AreaOfEffect.DIRECTIONAL)
			{
				actions[0] = false;
				actions[1] = false;
				actions[2] = true;
				
			}
			else if (ability.getCastArea() == AreaOfEffect.SINGLETARGET) 
			{
				single = true;
			}
		}
		
		if( single == true)
		{
		for( int i = 0 ; i < 5 ; ++i)
			for( int k = 0 ; k < 5 ; ++k)
				if(e.getSource().equals(champions[i][k]))
					try {
						game.castAbility(ability, i, k);
					} catch (NotEnoughResourcesException | AbilityUseException | InvalidTargetException
							| CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage());
					}
		}
		
		if(e.getSource().equals(leaderAbility))
		{
			try {
				game.useLeaderAbility();
				Champion c = game.getCurrentChampion();
				if(game.getFirstPlayer().getTeam().contains(c))
					abilityL1.setText("Leader Ability : Used");
				else
					abilityL2.setText("Leader Ability : Used");
			} catch (LeaderNotCurrentException | LeaderAbilityAlreadyUsedException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage());
			}
		}
		
		if(e.getSource().equals(endTurn))
		{
			String c ="";
			String type ="";
			game.endTurn();
			 if(game.getCurrentChampion() instanceof Hero)
				 type ="Hero";
			 else if( game.getCurrentChampion() instanceof AntiHero)
				 type ="AntiHero";
			 else
				 type ="Villain";
			 
			 c += "Name : " + game.getCurrentChampion().getName() +" " + type +  "\n" + "Hp : " +  game.getCurrentChampion().getCurrentHP() + "\n" + "Attack Damage : "+  game.getCurrentChampion().getAttackDamage() + "\n" +
						"Attack Range : " +  game.getCurrentChampion().getAttackRange() + "\n" + "Current Action Points : " +  game.getCurrentChampion().getCurrentActionPoints() + "\n" + 
						"Speed : " +  game.getCurrentChampion().getSpeed() + "\n" + "Mana : " + game.getCurrentChampion().getMana(); 
			 current.setIcon(new ImageIcon(game.getCurrentChampion().getName() + ".jpg"));
			 infoCurrent.setText(c);
		}
		
	
		
		if( game.checkGameOver() != null)
		{
			Player tmp = game.checkGameOver();
			JOptionPane.showMessageDialog(null, tmp.getName() + "HAS WON");
			move.setVisible(false);
			attack.setVisible(false);
			firstAbility.setVisible(false);
			secondAbility.setVisible(false);
			thirdAbility.setVisible(false);
			leaderAbility.setVisible(false);
			leaderAbility.setVisible(false);
			champion1.removeMouseListener(this);
			champion2.removeMouseListener(this);
			champion3.removeMouseListener(this);
			champion4.removeMouseListener(this);
			champion5.removeMouseListener(this);
			champion6.removeMouseListener(this);
			current.removeMouseListener(this);
		}
		
		String s ="";
		if(e.getSource().equals(champion1))
		{
			for( int i= 0 ; i< tmp1.get(0).getAppliedEffects().size() ; ++i )
			s += tmp1.get(0).getAppliedEffects().get(i).getName() + tmp1.get(0).getAppliedEffects().get(i).getDuration() + "\n";
			JOptionPane.showMessageDialog(null, s);
		}
		if(e.getSource().equals(champion2))
		{
			
			for( int i= 0 ; i< tmp1.get(1).getAppliedEffects().size() ; ++i )
				s += tmp1.get(1).getAppliedEffects().get(i).getName() + tmp1.get(1).getAppliedEffects().get(i).getDuration() + "\n";
				JOptionPane.showMessageDialog(null, s);
		}
		if(e.getSource().equals(champion3))
		{
			for( int i= 0 ; i< tmp1.get(2).getAppliedEffects().size() ; ++i )
				s += tmp1.get(2).getAppliedEffects().get(i).getName() + tmp1.get(2).getAppliedEffects().get(i).getDuration() + "\n";
				JOptionPane.showMessageDialog(null, s);
		}if(e.getSource().equals(champion4))
		{
			for( int i= 0 ; i< tmp2.get(0).getAppliedEffects().size() ; ++i )
				s += tmp2.get(0).getAppliedEffects().get(i).getName() + tmp2.get(0).getAppliedEffects().get(i).getDuration() + "\n";
				JOptionPane.showMessageDialog(null, s);
		}
		if(e.getSource().equals(champion5))
		{
			for( int i= 0 ; i< tmp2.get(1).getAppliedEffects().size() ; ++i )
				s += tmp2.get(1).getAppliedEffects().get(i).getName() + tmp2.get(1).getAppliedEffects().get(i).getDuration() + "\n";
				JOptionPane.showMessageDialog(null, s);
		}
		if(e.getSource().equals(champion6))
		{
			for( int i= 0 ; i< tmp2.get(2).getAppliedEffects().size() ; ++i )
				s += tmp2.get(2).getAppliedEffects().get(i).getName() + tmp2.get(2).getAppliedEffects().get(i).getDuration() + "\n";
				JOptionPane.showMessageDialog(null, s);
		}
		if(e.getSource().equals(current))
		{
			for( int i= 0 ; i< game.getCurrentChampion().getAppliedEffects().size() ; ++i )
				s += game.getCurrentChampion().getAppliedEffects().get(i).getName() + game.getCurrentChampion().getAppliedEffects().get(i).getDuration() + "\n";
				JOptionPane.showMessageDialog(null, s);
		}
		
		s ="";
		String t ="";
		
		for( int i = 0; i< 3 ; ++i)
		{
			Champion c = tmp1.get(i);
			 if(c instanceof Hero)
				 t ="Hero";
			 else if(c instanceof AntiHero)
				 t ="AntiHero";
			 else
				 t ="Villain";
			 s += "Name : " +c.getName() +" " + t +  "\n" + "Hp : " +  c.getCurrentHP() + "\n" + "Attack Damage : "+ c.getAttackDamage() + "\n" +
						"Attack Range : " +  c.getAttackRange() + "\n" + "Current Action Points : " +  c.getCurrentActionPoints() + "\n" + 
						"Speed : " + c.getSpeed() + "\n" + "Mana : " + c.getMana(); 
			info.get(i).setText(s);
			s= "";
		}
		
		int j = 0;
		for( int i = 3; i< 6 ; ++i)
		{
			Champion c = tmp2.get(j);
			 if(c instanceof Hero)
				 t ="Hero";
			 else if( c instanceof AntiHero)
				 t ="AntiHero";
			 else
				 t ="Villain";
			 s += "Name : " +c.getName() +" " + t +  "\n" + "Hp : " +  c.getCurrentHP() + "\n" + "Attack Damage : "+ c.getAttackDamage() + "\n" +
						"Attack Range : " +  c.getAttackRange() + "\n" + "Current Action Points : " +  c.getCurrentActionPoints() + "\n" + 
						"Speed : " + c.getSpeed() + "\n" + "Mana : " + c.getMana(); 
			info.get(i).setText(s);
			s= "";
			++j;
		}
		
		 if(game.getCurrentChampion() instanceof Hero)
			 t ="Hero";
		 else if( game.getCurrentChampion() instanceof AntiHero)
			 t ="AntiHero";
		 else
			 t ="Villain";
		 
		 s += "Name : " + game.getCurrentChampion().getName() +" " + t +  "\n" + "Hp : " +  game.getCurrentChampion().getCurrentHP() + "\n" + "Attack Damage : "+  game.getCurrentChampion().getAttackDamage() + "\n" +
					"Attack Range : " +  game.getCurrentChampion().getAttackRange() + "\n" + "Current Action Points : " +  game.getCurrentChampion().getCurrentActionPoints() + "\n" + 
					"Speed : " +  game.getCurrentChampion().getSpeed() + "\n" + "Mana : " + game.getCurrentChampion().getMana(); 
		 infoCurrent.setText(s);
		 main.add(infoCurrent);
		
	Object [][] check = game.getBoard();
		 
	 
	for( int i=0 ; i < 5; ++i)
	{
		for( int k = 0 ; k< 5 ; ++k)
		{
			if( check[i][k] == null)
			{
				champions[i][k].setIcon(null);
				champions[i][k].setText("");
			}
			
		}
	}
	
	for( int i=0 ; i < 5; ++i)
	
		for( int k = 0 ; k< 5 ; ++k)
	 if( check[i][k] instanceof Cover )
			champions[i][k].setText( ((Cover)check[i][k]).getCurrentHP()  + "");
	
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	String s ="";
		if(e.getSource().equals(firstAbility))
	{
			String type ="";
			Ability a = game.getCurrentChampion().getAbilities().get(0);
		s += "Name : " + a.getName() + "\n" +  "AreaOfEffect : " + a.getCastArea() + "\n" + "CastRange : " + a.getCastRange() + "\n" + "ManaCost : " + a.getManaCost() + "\n" +
			"Actions : " +  a.getRequiredActionPoints() + "\n" + "BaseCoolDown : " + a.getBaseCooldown() + "\n" + "CurrentCoolDown : " + a.getCurrentCooldown() + "\n";
		if( a instanceof DamagingAbility)
			type += "Type : DamagingAbility" + "\n" + "DamagingAmount : " + ((DamagingAbility)a).getDamageAmount();
		else if( a instanceof HealingAbility)
			type += "Type : HealingAbility" + "\n" + "DamagingAmount : " + ((HealingAbility)a).getHealAmount();
		else 
			type += "Type : CrowdControlAbility" + "\n" + "Effect : " + (((CrowdControlAbility)a).getEffect().getName()) + "  " + (((CrowdControlAbility)a).getEffect().getDuration()) ;
		s += type;
	}
	
		if(e.getSource().equals(secondAbility))
		{
				String type ="";
				Ability a = game.getCurrentChampion().getAbilities().get(1);
			s += "Name : " + a.getName() + "\n" +  "AreaOfEffect : " + a.getCastArea() + "\n" + "CastRange : " + a.getCastRange() + "\n" + "ManaCost : " + a.getManaCost() + "\n" +
				"Actions : " +  a.getRequiredActionPoints() + "\n" + "BaseCoolDown : " + a.getBaseCooldown() + "\n" + "CurrentCoolDown : " + a.getCurrentCooldown() + "\n";
			if( a instanceof DamagingAbility)
				type += "Type : DamagingAbility" + "\n" + "DamagingAmount : " + ((DamagingAbility)a).getDamageAmount();
			else if( a instanceof HealingAbility)
				type += "Type : HealingAbility" + "\n" + "DamagingAmount : " + ((HealingAbility)a).getHealAmount();
			else 
				type += "Type : CrowdControlAbility" + "\n" + "Effect : " + (((CrowdControlAbility)a).getEffect().getName()) + "  " + (((CrowdControlAbility)a).getEffect().getDuration()) ;
			s +=type;
		}
		if(e.getSource().equals(thirdAbility))
		{
				String type ="";
				Ability a = game.getCurrentChampion().getAbilities().get(2);
			s += "Name : " + a.getName() + "\n" +  "AreaOfEffect : " + a.getCastArea() + "\n" + "CastRange : " + a.getCastRange() + "\n" + "ManaCost : " + a.getManaCost() + "\n" +
				"Actions : " +  a.getRequiredActionPoints() + "\n" + "BaseCoolDown : " + a.getBaseCooldown() + "\n" + "CurrentCoolDown : " + a.getCurrentCooldown() + "\n";
			if( a instanceof DamagingAbility)
				type += "Type : DamagingAbility" + "\n" + "DamagingAmount : " + ((DamagingAbility)a).getDamageAmount();
			else if( a instanceof HealingAbility)
				type += "Type : HealingAbility" + "\n" + "DamagingAmount : " + ((HealingAbility)a).getHealAmount();
			else 
				type += "Type : CrowdControlAbility" + "\n" + "Effect : " + (((CrowdControlAbility)a).getEffect().getName()) + "  " + (((CrowdControlAbility)a).getEffect().getDuration()) ;
			s += type;
		}
		
		infoAbility.setText(s);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		infoAbility.setText("");
		
	}
	
	
	
	
}
