package model.views;

import java.util.ArrayList;

import model.world.Champion;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Start implements ActionListener , KeyListener{

	private ArrayList<Champion> champions;
	private JFrame window;
	private JButton next;
	private JLabel title;
	private JLabel back;
	
	public Start( ArrayList<Champion> champions) 
	{
		this.champions = champions;
		window = new JFrame("Marvel: Ultimate War");
		window.setSize(600,400);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setLocationRelativeTo(null);
		window.addKeyListener(this);
		window.setLayout(null);
		window.setIconImage(new ImageIcon("logo.jpg").getImage());
		
		back = new JLabel();
		back.setBounds(0,0,600,400);
		back.setIcon( new ImageIcon("wallpaper.jpg"));
		title = new JLabel("Marvel: Ultimate War");
		title.setBounds(150,100,300,50);
		title.setForeground(new Color(128,0,0));
		title.setFont(new Font("",Font.BOLD,30));
		back.add(title);
		
		
		next =  new JButton("Next");
		next.setBounds(200,175,175,75);
		next.setBackground(new Color(128,0,0));
		next.setBorder(BorderFactory.createLineBorder(Color.white,2 ));
		next.setForeground(Color.white);
		next.setFont( new Font("",Font.BOLD,16));
		next.setFocusable(false);
		next.addActionListener(this);
		back.add(next);
		
		window.add(back);
		window.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		window.dispose();
		String f = JOptionPane.showInputDialog(null, "Please Enter First Player Name.");
		String s = JOptionPane.showInputDialog(null, "Please Enter Second Player Name.");
		characters c  = new characters(champions , f ,s);

		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		System.out.println(e.getKeyCode());
		
	}
	
	
	
	
	
	
	
}
